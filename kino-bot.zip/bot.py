from aiogram import Bot, Dispatcher, types, executor
import json, os

API_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

FAYL = 'kinolar.json'

def yukla():
    try:
        with open(FAYL, 'r') as f:
            return json.load(f)
    except:
        return {}

def saqla(kinolar):
    with open(FAYL, 'w') as f:
        json.dump(kinolar, f, indent=2)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.reply("🎬 Salom! Kod yuboring yoki kino qo‘shish uchun admin bo‘ling.")

@dp.message_handler(commands=['add'])
async def add(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return await message.reply("⛔ Bu buyruq faqat admin uchun.")

    try:
        _, malumot = message.text.split(' ', 1)
        nom, tav, link = [i.strip() for i in malumot.split('|')]
        kinolar = yukla()
        kod = str(len(kinolar) + 1)
        kinolar[kod] = {'nom': nom, 'tav': tav, 'link': link}
        saqla(kinolar)
        await message.reply(f"✅ Qo‘shildi! Kod: {kod}")
    except:
        await message.reply("❗ Format: /add Kino nomi | Tavsif | Link")

@dp.message_handler(lambda msg: msg.text.isdigit())
async def get_kino(message: types.Message):
    kod = message.text.strip()
    kinolar = yukla()
    if kod in kinolar:
        k = kinolar[kod]
        await message.reply(f"🎥 {k['nom']}

{k['tav']}
📺 [Tomosha qilish]({k['link']})", parse_mode="Markdown")
    else:
        await message.reply("❌ Bunday kodli kino topilmadi.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
